import os
import sys
import time
import random
import colorama
from pygame import mixer

# map for use when player views map
map = '''
------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------*@@@@*-@@@@@@@@)-------------------------------------------**----------------------------*)--)@}-*-----------------------------------
--------------)@@@@@@@--@@@@@@@@@)-------------------------------------*@@@@@}---@@}-----------------*@}@@)@@@@)}@}@}---------------------------------
-------------*@@@@@@}*@@@@@@@@@@}--------------------------------------)@@))}*)@@@@@------------------)@})})})))))))}}@-*-----------------------------
----------------}}*--}*-}@@)-})-*---------------------------------------------@@@@@)--------------------@})}})})))))))})}@@}*-------------------------
----------------}@@------------------------------------------------------------------------------------)@}))))))))})))}))))}}@@@@@}-------------------
---------------------------------------------------------------------------------------------------------}@@))}}))))))))))))))))))@@*)}*--------------
-----------------------------------------------------------------------------------------------------------*@})))) Pyro Wizard)))})))}@*--------------
-------------------------------------------------------------------------------------------------------------@}))))}}))}})))))})))})@*----------------
-------------------------------------------------------------------------------------------------------------*@}))))))}}})}}))))))})@*----------------
-----------------)@}}**}**)@}--------------------------------------------------------------------------------)@))}))}))}))}))})})))))}@*--------------
-----------------*@@@@@@@@@@@@@@@)*}@@@@@---------------------------------------------------------------------}@}))}))})}}))))))}}))}})}@-------------
-----------------@@@@@@@@@@@@@@@@@@@@@@@@@@@@}------------------------------------------------------------------@@})))})}))}})))))))))))@}**----------
----------------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*------------------------------------------------------------------*@}}}))))))))}}}})})))))}}}@---------
----------------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@----------------------------------------------------------------------@})))))))}))))}}))}@@)*---------
----------------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*----------------------------------------------------------------------*@}))}))))))}))))}@*-----------
--------------*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@----------------------------------------------------------*@@@@)--------*@))}) Ignisum }]@------------
-------------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@}*-*------------------------------------------------------)@@@@@@@@@@@@@@}})))})})})))))@-------------
------------)@@@@@@@@@@ Wizard King @@@@@@@@@@@@@@------------------------------------------------**@@@@@@@@@@@@@@@@@@@@@@@@})))}}}@}@@@--------------
------------*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*----------------------------------------*}}}*-@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@}-*-----------------
--------------}@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-----------------------------------------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-----)}-----**------
----------------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*--------------------------------------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@)---@@@@@-----@@*-----
---------------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@)*--------------------------------------*@@@@@@@@@@@@}@}@@-----@@@@@@@@@@@@@@@@)-----*}@@@}---@)------
---------------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@--------------------------------------}@@@@@@@@@@@ Shadow Wizard @@@@@@@@@@@})-------*@@@@)@@@*-@*------
-------------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@---------------------------------------@@@@@@@@@@@@@@@@-----@@}--*)@@@@@@@@@}------@@* Hydro Wizard *@*--
------------)@@@@@@@@@@@@@@@ Wizard Casino @@@-------------------------------------)@@@@@@@@@@@@@@@)------)@@@@@@@@@@@@@@-------@@@*--)})@@)-*@@)@----
----------*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*---------------------------------------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*----------@@-@@@@@*@@@*@----
----------@@@@@@@@@@@@@@@@@@@@@)--*}@@@@@*-----------------------------------------}@@@@@@@@@@@ Tenebrisus @@@@@@@@@@@@@@-)@--------)@@@*@@)@@}}-@)}@-
-------------****@@*-----@@@**-------**-------------------------------------------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-----*@} Humidum @@@*@@*-
--------------------------------------------------------------------------------*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@}----*@@*@*@@}@}--@)*----
------------------------------------------------------------------------------*)@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*-------@@@@))**}@-@*)---
------------------------------------------------------------------------------@@@@@@@@@@@@@@@@@**@@@@@@@@@@@@@@@@@@@@@@@@@@@---------*--*---)@}--@)}--
--------------------------------------------------------------------------*@@@@@@@@@@@@@@@@@@}@@}-----*@@@@@@@@@@@@@@@@@@@@@@-------------------------
--------------------------------------------------------------------------)@@@@@@@@@@@@@@@@@@@@@@}----)@@@@@@}@}@@@@@@@@@}}}@*------------------------
--------------------------------------------------------------------------@@@@@@@@@@@@@@@@@@@@@@@---------@@}} Air Wizard }}}@@------------------*)@@)
--------------------------------------------------------------------------@@@@@@@@@@@@@@@@@@@@@@*---------@@@@@@@}@@@}@}@@}@@@)----------------@@@@@)*
-------------------------------------------------------------------------*@ Saxus Village @@@@@@@@)@--------*@@@@@@@@@}}}@@}@@@----------Ventus Bay---
-----------------------------------------------------------------------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@)------*----@@@@@@@@}}@@@@@@)----**@@@@@@@@@@-----
-----------------------------------------------------------------------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@)----------@@}@@@@}@@@@}}}@@@@-@@@@@@@@@}}@@*----
------------------------------*@@@@@*-----------------------------------)@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*-----------*@@@@@@@@@@@@@@@@}@@@@@@}}@@*------
---------------------------*}@@@@@@@}----------------------------------*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-------------)@@@}@}@@@@@@@@@}}}@}@}@@@@@*------
---------------------------)@@@@@@@@)---------------------------------}@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@--------------*@@@@}@}@@@@}}@@@@@@@@@@@}-------
----------------------------}@@@@@@@@---------------------------------)@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@}-----------------*)}@*-*@@@@@@@@@@@@@@@@)------
-------------------------------)@@@@*-------------------------------------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*---------------*-------*)*@@@@@@-*}@@@)------
-------------------------------------------------------------------------*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*------------------------------)}-------------
-----------------------------------------------------------------------------@@@@@@ Geo Wizard @@@@@@@@@)*--------------------------------------------
-----------------------------------------------------------------------------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-------------------------------------------
------------------------------------------------------------------------------@@@@@@@@@@@@@@@@}***@)----*@--------------------------------------------
--------------------------------------------------------------------------------------@@@))}----------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------*---------------------------------
-------------------------------------------------------------------------------------------------------------------)@@@-------------------------------
--------------------------------------------------------------------------------------------------------------------*)--------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------'''
os.system('cls' if os.name == 'nt' else 'clear')
# set color to white upon startup
print(colorama.Fore.WHITE)
#any time you see an input() like this, its so that the user can press enter and continue


# initialising music to play later. can only play one song at once.
mixer.init()
#mixer.music.load("test.mp3")
mixer.music.set_volume(0.7)
# mixer.music.play()



# If you want to add more sfx make sure you specify sound. sounds can use multiple channels
#initialising sounds
revolverSound = mixer.Sound("assets/revolver.mp3")
assaultRifleSound = mixer.Sound("assets/assaultrifle.mp3")
pistolSound = mixer.Sound("assets/pistol.mp3")
shotgunSound = mixer.Sound("assets/shotgun.mp3")
reloadSound = mixer.Sound("assets/reload.mp3")
wizardcry1 = mixer.Sound("assets/wizardcry1.mp3")
wizardcry2 = mixer.Sound("assets/wizardcry2.mp3")
wizardcry3 = mixer.Sound("assets/wizardcry3.mp3")
# creating player variables
playerName = "Testplayer"
playerHealth = 100
playerDefence = 50
playerTempDefence = 0
playerActionPoints = 3

class spellLevels:
	def __init__(self, spellLevel, spellXP):
		self.spellLevel = spellLevel
		self.spellXP = spellXP

playerSpells = spellLevels(1, 0)
# menuloop controls while statements
menuLoop = 1

# battle-specific variables/ functions

colorama.Style.DIM

battleTurn = 1



# enemy class, max health is used to compare against current health and determine percentage
class Enemy:
	def __init__(self, name, health, maxHealth, defence, atk, accuracy, spell1, spell2, spell3):
		self.name = name
		self.health = health
		self.maxHealth = maxHealth
		self.defence = defence
		self.atk = atk
		self.accuracy = accuracy
		self.spell1 = spell1
		self.spell2 = spell2
		self.spell3 = spell3

# class for body parts that will be shot.
class Target:
	def __init__(self, accuracy, damage):
		self.accuracy = accuracy
		self.damage = damage


#class for guns. makes accessing info about the gun easier
class Gun:
	def __init__(self, attack, ammo, maxAmmo, accuracy, sound):
		self.attack = attack
		self.ammo = ammo
		self.maxAmmo = maxAmmo
		self.accuracy = accuracy
		self.sound = sound

# menu update is specifically for menus where the user enters an option. 4 possible options, if you want an option removed just add a blank string in its place.

def menuUpdate(description, description2,  option1, option2, option3, option4):
	os.system('cls' if os.name == 'nt' else 'clear')
	print(description)
	print(description2)
	print("___________________________________________________________________________________\n")
	print(option1, "     ", end=' ')
	print(option2, "     ", end=' ')
	print(option3, "     ", end=' ')
	print(option4, "\n \n")
	return input()


# viewing stats in battle.
def statcheck(stat):
	os.system('cls' if os.name == 'nt' else 'clear')
	print(stat.name, "'s stats: \n")
	print("HEALTH = ", stat.health)
	print("DEFENCE = ", stat.defence)
	print("ATTACK = ", stat.atk)
	input()

#dialogue lines for enemies plus ability for enemies to speak function
hitLines = ["ARGH, I'll make you pay for that!", "OW! curse you!", "OW! What dark magic fuels that wretched thing??", "OWIE! Where the hell did you get that thing?", "OUCH, wait until the wizard king hears about this!"]
missLines = ["AHAHAHA! No amount of magic will fix your terrible aim!", "Imagine not being able to guide your shots using sorcery, loser!", "Even with that thing, you're no match for a wizard!", "No matter how hard you try, your resistance will be in vain.", "That thing is no match against our magic."]
def enemyMessage(message, name):
	if message == "hit":
		return (colorama.Fore.RED + name + colorama.Fore.WHITE + ": " + hitLines[random.randint(0, 4)] )
	elif message == "miss":
		return (colorama.Fore.RED + name + colorama.Fore.WHITE + ": " + missLines[random.randint(0, 4)])
	else:
		return (colorama.Fore.RED + name + colorama.Fore.WHITE + ": " + message)


# plays sound whe wizard gets hit
def enemyPain():
	randomSoundChooser = random.randint(1, 3)
	if randomSoundChooser == 1:
		return wizardcry1
	if randomSoundChooser == 2:
		return wizardcry2
	if randomSoundChooser == 3:
		return wizardcry3


# spell menu for casting spells
def spellMenu(description1, description2):
	os.system('cls' if os.name == 'nt' else 'clear')
	print(description1)
	print(description2)
	print("___________________________________________________________________________________\n")
	if playerSpells.spellLevels >= 1:
		print("SHIELD: adds 10+ defence for one turn.")
	return input()


#displays fancy message on screen. clears screen beforehand
def prompt(str):
	os.system('cls' if os.name == 'nt' else 'clear')
	for word in str.split():
		time.sleep(0.05)
		print(f'{word:>1} ', end='')
		sys.stdout.flush()
	time.sleep(0.01)
	print("\n")
	return input()

def oldPrompt(str):
	os.system('cls' if os.name == 'nt' else 'clear')
	print(str)
	return input()

wizard1 = Enemy("testwizard", 100, 100, 0.2, 30, 70, "fireball", "healing", "spirit's aid")
head = Target(50, 40,) #35
torso = Target(90, 10) #50
legs = Target(75, 15) #45
arms = Target(75, 15)#45

prompt("YOUR JOURNEY IS ABOUT TO BEGIN.")
playerName = prompt("BUT FIRST, WHAT IS YOUR NAME? TYPE IT BELOW.")
playerOption = prompt("IS " + playerName + " YOUR NAME? YES OR NO")
while playerOption != "yes":
    playerName = prompt("REENTER YOUR NAME BELOW.")
    playerOption = prompt("IS " + playerName + " YOUR NAME? YES OR NO")
prompt(playerName + " IS YOUR NAME.")
prompt("Your story is about to begin.")
os.system('cls' if os.name == 'nt' else 'clear')


npcName = (colorama.Fore.YELLOW + colorama.Back.BLUE + "Walmart Employee" + colorama.Fore.WHITE + colorama.Back.RESET)
playerName = (colorama.Fore.LIGHTBLUE_EX + playerName + colorama.Fore.WHITE)

def AMURICA(str):
    for chr in str:
        sys.stdout.write(chr)
        sys.stdout.flush()
        time.sleep(0.05)
    return print(colorama.Style.RESET_ALL, end="")

oldPrompt(map)
prompt("You are a true " + colorama.Fore.BLUE + "A" + colorama.Fore.WHITE + "M" + colorama.Fore.RED + "E" + colorama.Fore.BLUE + "R" + colorama.Fore.WHITE + "I" + colorama.Fore.RED + "C" + colorama.Fore.BLUE + "A" + colorama.Fore.WHITE + "N"  + " patriot. Recently, whilst hunting for oil, your gun broke. This was devastating, but not to worry! Your local Walmart sells firearms.")
prompt("You run as fast as you can to your gigantic pick-up truck, decorated with stickers of the American flag and a picture of a bald eagle laying a grenade like its an egg.")
prompt("You can't waste a single second. After all, what will you do if 4 rapscallions break into your home to steal your oil?")
prompt("After a 15 minute drive and multiple run-over pedestrians, you finally reach the beautifiul Walmart. You step out of your truck and walk into thew Walmart.")
prompt("Dozens of aisles line your view, each filled with the typical items and people you'd expect to find in a Walmart. In one, a 400 pound beast in a mobility scooter is stuffing a seventeenth bag of cheetos into their poor shopping cart.")
prompt("In another aisle, you see a Karen screaming at an employee because the 10 year old expired coupon they have isnt valid.")
prompt("All of it, it reminds you that you are in the land of the Free. \n America.")
prompt(npcName + ": 'Welcome to Walmart, how can I help you today?'")
prompt(playerName + ": 'Hey, do you know what aisle has guns?'")
prompt(npcName + ": 'Certainly! come with me to aisle 27.'")
prompt("The " + npcName + " leads you to aisle 27. There on the wall are dozens of guns lined up on display. You thank the " + npcName + " and begin browsing. After a while, you've narrowed down what you want to just 4 options.")

playerOption = " "
playerWeapon = " "
while menuLoop == 1:
	playerWeapon = menuUpdate("Pick your weapon.", "weapons have different stats. this choice is irreversible. type the number of your desired weapon.", "1. pistol", "2. revolver", "3. assault rifle", "4. shotgun")
	if playerWeapon == "1" or playerWeapon == "2" or playerWeapon == "3" or playerWeapon == "4":
		if playerWeapon == "1":
			playerOption = str(menuUpdate("The" + colorama.Fore.LIGHTRED_EX + " pistol " + colorama.Fore.WHITE + "can hold 12 bullets, deals 10 dmg when shot, shoots once per turn, and has a 70% accuracy. do you want it?", "      ,_________\n     Y II_____==|\n     )  /J\n    /__/", "yes", " ", " ", "no"))
			if playerOption == "yes":
				playerWeapon = "pistol"
				weapon = Gun(10, 12, 12, 90, pistolSound)
				menuLoop = 2
		elif playerWeapon == "2":
			playerOption = str(menuUpdate("The" + colorama.Fore.LIGHTRED_EX + " revolver " + colorama.Fore.WHITE + "can hold 6 bullets, deals 20 dmg when shot, shoots once per turn, and has a 70% accuracy. do you want it?", "      __ _______,\n    _Y__]-------'\n   / _/J\n  |_|\n", "yes", " ", " ", "no"))
			if playerOption == "yes":
				playerWeapon = "revolver"
				weapon = Gun(20, 6, 6, 90, revolverSound)
				menuLoop = 2
		elif playerWeapon == "3":
			playerOption = str(menuUpdate("The" + colorama.Fore.LIGHTRED_EX + " assault rifle " + colorama.Fore.WHITE + "can hold 30 bullets, deals 15 dmg when shot, shoots thrice per turn, and has a 40% accuracy. do you want it?", "                 ___\n                [_-_]\n      _________,-'-'--_______/|\n     |       _     ___|_.......-------=\n     |__...'' / /J|  |\n             /_/   \\__\\", "yes", " ", " ", "no"))
			if playerOption == "yes":
				playerWeapon = "assault rifle"
				weapon = Gun(5, 30, 30, 80, assaultRifleSound)
				menuLoop = 2
		elif playerWeapon == "4":
			playerOption = str(menuUpdate("The" + colorama.Fore.LIGHTRED_EX + " shotgun " + colorama.Fore.WHITE + "can hold 2 rounds, deals 35 dmg when shot, shoots once per turn, and has a 50% accuracy. do you want it?", "                      _,______________________________,\n       _______..... Y.____|___|______________________|\n      |             _____.......------'\n      |        ..'''   J\n      |___...''\n", "yes", " ", " ", "no"))
			if playerOption == "yes":
				playerWeapon = "shotgun"
				weapon = Gun(30, 2, 2, 70, shotgunSound)
				menuLoop = 2
	else:
		prompt("that was not a valid selection!")
		menuLoop = 1

# FIGHT TIME
prompt("you have picked the " + playerWeapon + ".")

def fight(wizard1, menuLoopValue, message):
	wizard1.name = colorama.Fore.LIGHTBLUE_EX + wizard1.name + colorama.Fore.WHITE
	missTurn = 0
	battleTurn = 1
	menuLoop = menuLoopValue
	playerCastSpell = False
	while menuLoop == menuLoopValue:
		while wizard1.health > 0:
			while battleTurn == 1:
				playerSpell = " "
				playerTempDefence = 0
				playerOption = menuUpdate( message + "\n \nyour ammo:" + str(weapon.ammo) + " / " + str(weapon.maxAmmo),
										  "Choose an action: (currently only fighting works. Wizard doesnt fight back yet.) ", "FIGHT",
										  "SPELLS", "EXTRA", "RUN AWAY")
				if playerOption.lower() == "fight" or playerOption.lower() == "spells" or playerOption.lower() == "extra" or playerOption.lower() == "run away":
					if playerOption.lower() == "fight":
						playerHit = menuUpdate("Where do you want to hit?", "Type 'back' to go back.", "head", "torso", "legs",
											   "arms")
						if playerHit.lower() == "head" or playerHit.lower() == "torso" or playerHit.lower() == "legs" or playerHit.lower() == "arms":
							if weapon.ammo == 0:
								prompt("No ammo! reloading skips your turn.")
								weapon.ammo = weapon.maxAmmo
								mixer.Sound.play(reloadSound)
								battleTurn = 2
							else:
								if playerWeapon != "assault rifle":
									if playerHit.lower() == "head":
										playerHitPercent = random.randint(1, 100)
										bodyHitPercent = random.randint(1, 100)
										weapon.ammo = weapon.ammo - 1
										mixer.Sound.play(weapon.sound)
										if playerHitPercent < weapon.accuracy and bodyHitPercent < head.accuracy:
											mixer.Sound.play(enemyPain())
											wizard1.health = wizard1.health - (head.damage + (
														(1 - wizard1.defence) * weapon.attack))
											prompt("hit! enemy health: " + str(wizard1.health) + " / " + str(
												wizard1.maxHealth))
											prompt(enemyMessage("hit", wizard1.name))
											battleTurn = 2
										else:
											prompt("miss! enemy health: " + str(wizard1.health) + " / " + str(
												wizard1.maxHealth))
											prompt(enemyMessage("miss", wizard1.name))
											battleTurn = 2
									elif playerHit.lower() == "torso":
										playerHitPercent = random.randint(1, 100)
										bodyHitPercent = random.randint(1, 100)
										weapon.ammo = weapon.ammo - 1
										mixer.Sound.play(weapon.sound)
										if playerHitPercent < weapon.accuracy and bodyHitPercent < torso.accuracy:
											mixer.Sound.play(enemyPain())
											wizard1.health = wizard1.health - (torso.damage + (
														(1 - wizard1.defence) * weapon.attack))
											prompt("hit! enemy health: " + str(wizard1.health) + " / " + str(
												wizard1.maxHealth))
											battleTurn = 2
											prompt(enemyMessage("hit", wizard1.name))
										else:
											battleTurn = 2
											prompt("miss! enemy health: " + str(wizard1.health) + " / " + str(wizard1.maxHealth))
											prompt(enemyMessage("miss", wizard1.name))
											
									elif playerHit.lower() == "legs": 
										playerHitPercent = random.randint(1, 100)
										bodyHitPercent = random.randint(1, 100)
										weapon.ammo = weapon.ammo - 1
										mixer.Sound.play(weapon.sound)
										if playerHitPercent < weapon.accuracy and bodyHitPercent < legs.accuracy:
											mixer.Sound.play(enemyPain())
											wizard1.health = wizard1.health - (legs.damage + (
														(1 - wizard1.defence) * weapon.attack))
											prompt("hit! enemy misses turn! enemy health: " + str(
												wizard1.health) + " / " + str(wizard1.maxHealth))
											battleTurn = 1
											prompt(enemyMessage("hit", wizard1.name))
										else:
											prompt("miss! enemy health: " + str(wizard1.health) + " / " + str(
												wizard1.maxHealth))
											prompt(enemyMessage("miss", wizard1.name))
											battleTurn = 2
									elif playerHit.lower() == "arms":
										playerHitPercent = random.randint(1, 100)
										bodyHitPercent = random.randint(1, 100)
										weapon.ammo = weapon.ammo - 1
										mixer.Sound.play(weapon.sound)
										if playerHitPercent < weapon.accuracy and bodyHitPercent < arms.accuracy:
											mixer.Sound.play(enemyPain())
											wizard1.health = wizard1.health - (arms.damage + (
														(1 - wizard1.defence) * weapon.attack))
											prompt("hit! enemy accuracy decreased! enemy health: " + str(
												wizard1.health) + " / " + str(wizard1.maxHealth))
											wizard1.accuracy = wizard1.accuracy - 10
											battleTurn = 2
											prompt(enemyMessage("hit", wizard1.name))
										else:
											prompt("miss! enemy health: " + str(wizard1.health) + " / " + str(
												wizard1.maxHealth))
											battleTurn = 2
											prompt(enemyMessage("miss", wizard1.name))
								else:
									if playerHit.lower() == "head":
										for x in range(0, 3):
											playerHitPercent = random.randint(1, 100)
											bodyHitPercent = random.randint(1, 100)
											weapon.ammo = weapon.ammo - 1
											mixer.Sound.play(weapon.sound)
											if playerHitPercent < weapon.accuracy and bodyHitPercent < head.accuracy:
												mixer.Sound.play(enemyPain())
												wizard1.health = wizard1.health - (head.damage + (
															(1 - wizard1.defence) * weapon.attack))
												prompt("hit! enemy health: " + str(wizard1.health) + " / " + str(
													wizard1.maxHealth))
												battleTurn = 2
												prompt(enemyMessage("hit", wizard1.name))
											else:
												prompt("miss! enemy health: " + str(wizard1.health) + " / " + str(
													wizard1.maxHealth))
												battleTurn = 2
												prompt(enemyMessage("miss", wizard1.name))
									elif playerHit.lower() == "torso":
										for x in range(0, 3):
											playerHitPercent = random.randint(1, 100)
											bodyHitPercent = random.randint(1, 100)
											weapon.ammo = weapon.ammo - 1
											mixer.Sound.play(weapon.sound)
											if playerHitPercent < weapon.accuracy and bodyHitPercent < torso.accuracy:
												mixer.Sound.play(enemyPain())
												wizard1.health = wizard1.health - (torso.damage + (
															(1 - wizard1.defence) * weapon.attack))
												prompt("hit! enemy health: " + str(wizard1.health) + " / " + str(
													wizard1.maxHealth))
												battleTurn = 2
												prompt(enemyMessage("hit", wizard1.name))
											else:
												prompt("miss! enemy health: " + str(wizard1.health) + " / " + str(
													wizard1.maxHealth))
												battleTurn = 2
												prompt(enemyMessage("miss", wizard1.name))
									elif playerHit.lower() == "legs":
										for x in range(0, 3):
											playerHitPercent = random.randint(1, 100)
											bodyHitPercent = random.randint(1, 100)
											weapon.ammo = weapon.ammo - 1
											mixer.Sound.play(weapon.sound)
											if playerHitPercent < weapon.accuracy and bodyHitPercent < legs.accuracy:
												mixer.Sound.play(enemyPain())
												wizard1.health = wizard1.health - (legs.damage + ((1 - wizard1.defence) * weapon.attack))
												prompt("hit! enemy misses turn! enemy health: " + str(
													wizard1.health) + " / " + str(wizard1.maxHealth))
												missTurn = 1
												prompt(enemyMessage("hit", wizard1.name))
											else:
												prompt("miss! enemy health: " + str(wizard1.health) + " / " + str(
													wizard1.maxHealth))
												prompt(enemyMessage("miss", wizard1.name))
										if missTurn == 0:
											battleTurn = 2
										else:
											battleTurn = 1
											missTurn = 0
									elif playerHit.lower() == "arms":
										for x in range(0, 3):
											playerHitPercent = random.randint(1, 100)
											bodyHitPercent = random.randint(1, 100)
											weapon.ammo = weapon.ammo - 1
											mixer.Sound.play(weapon.sound)
											if playerHitPercent < weapon.accuracy and bodyHitPercent < arms.accuracy:
												mixer.Sound.play(enemyPain())
												wizard1.health = wizard1.health - (arms.damage + (
															(1 - wizard1.defence) * weapon.attack))
												prompt("hit! enemy accuracy decreased! enemy health: " + str(
													wizard1.health) + " / " + str(wizard1.maxHealth))
												wizard1.accuracy = wizard1.accuracy - 10
												battleTurn = 2
												prompt(enemyMessage("hit", wizard1.name))
											else:
												prompt("miss! enemy health: " + str(wizard1.health) + " / " + str(
													wizard1.maxHealth))
												battleTurn = 2
												prompt(enemyMessage("miss", wizard1.name))
						# else:
						elif playerHit == "back":
							battleTurn = 1
						else:
							prompt("invalid selection!")
					elif playerOption.lower() == "spells":
						playerOption  = spellMenu("Choose a spell. More spells become available to you the higher level you are.", "You can only use one spell per turn. using spells will not end your turn. \n ACTION POINTS:" + str(playerActionPoints) + "\n Type 'back' to go back.")
						if playerOption.lower() == "back":
							battleTurn = 1
						elif playerOption.lower() == "shield" and playerCastSpell == False and playerSpells.spellLevel >= 1:
							playerCastSpell = True
							playerTempDefence += 10
							prompt("You cast shield! Your defence is increased by 10 for this turn.")
							playerSpells.spellXP += 5
			# else:
			if wizard1.health < 0:
				prompt("you killed him! yippee!!!")
				battleTurn = 0
				menuLoop = menuLoopValue + 1
			while battleTurn == 2:
				playerCastSpell = False
				prompt("the wizard's turn.")
				battleTurn = 1

fight(wizard1, 2, "THE WIZARD " + colorama.Fore.RED + wizard1.name + colorama.Fore.WHITE + " APPROACHES")
